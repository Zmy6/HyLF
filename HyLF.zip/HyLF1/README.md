# HyLF

Implementation of **HyLF: Sparse Angular Super-resolution from Hybrid Light Fields without Known Camera Parameters**, published in *IEEE Transactions on Circuits and Systems for Video Technology* (2026).

Paper: [doi:10.1109/TCSVT.2026.3688726](https://doi.org/10.1109/TCSVT.2026.3688726)

## Repository identity

This code was developed from [HyperReel](https://github.com/facebookresearch/hyperreel), but it is a HyLF implementation rather than a HyperReel release. The public surface has been renamed around HyLF and reduced to the sparse angular reconstruction path:

- the Python package is `hylf`;
- the learned unknown-camera transform is `HyLFSystem.parameterize_hybrid_rays`;
- the representation is exposed as `HybridRayEmbedding` and `PlanarVoxelGrid`;
- datasets are loaded by `SparseAngularLightFieldDataset`;
- experiment files and scripts use HyLF and paper-ablation names.

## Installation

The environment file pins Python 3.10, PyTorch 2.1.2, CUDA 12.1, torchvision 0.16.2, Hydra 1.3.2, and PyTorch Lightning 1.9.5. This combination has been validated on an RTX 3090.

```bash
conda env create -f environment.yml
conda activate hylf
```

Training the full planar voxel model requires an NVIDIA GPU with substantial memory. Reduce the voxel counts and batch size in `conf/experiment/model/hylf.yaml` and `conf/experiment/training/hylf.yaml` for smaller GPUs.

## Data

Each scene directory must contain only a lexicographically sortable 9x9 set of 81 RGB view images. The expected layout is:

```text
data/
  HCI_new/
    bicycle/
      <81 view images>
    boxes/
  INRIA/
    Bee/
      <81 view images>
  30scene/
    Cars/
      <81 view images>
```

The dataset directory and scene name are command-line arguments; the loader does not encode dataset-specific camera calibration. `scripts/train_experiment.sh` defaults to `/data`, while the paper-suite scripts accept `DATA_ROOT` and currently default to `/root/autodl-tmp/InstantSplat-main/data`.

## Training

All scene scripts use the same interface:

```text
<script> <gpu-id> <scene> <angular-step> <dataset-directory> [hydra-overrides...]
```

For example, train HyLF on the HCI `bicycle` scene using the four corner views of a centered 7x7 angular grid:

```bash
bash scripts/train_hylf.sh 0 bicycle 6 HCI_new
```

The angular step determines the reconstructed grid:

| Step | Sparse input | Reconstructed grid |
| ---: | :---: | :---: |
| 6 | 2x2 | 7x7 |
| 7 | 2x2 | 8x8 |
| 8 | 2x2 | 9x9 |

For step 6, the centered 7x7 grid uses source rows and columns 1 through 7. Training uses the four corners with flattened source indices `010`, `016`, `064`, and `070`; validation and testing use the other 45 views. The shared `scripts/train_experiment.sh` computes the centered angular bounds for each step. Direct runs write checkpoints to `checkpoints/<experiment>/` and validation images to `logs/<experiment>/` unless Hydra overrides specify other roots.

To reproduce the paper's Table 1-3 scene suite for 2x2 to 7x7 reconstruction, run the resumable four-scene queue:

```bash
DATA_ROOT=/path/to/data \
ARTIFACT_ROOT=/path/to/HyLF_runs \
METRICS_ROOT=/path/to/HyLF_runs/metrics/epoch_30 \
PYTHON_BIN=/path/to/python \
bash scripts/train_paper_tables.sh
```

The queue covers eight HCI scenes, five INRIA scenes, and five Stanford Archive scenes. It resumes an incomplete scene from `last.ckpt`, skips scenes that already have the expected validation images, and runs `testY.py` after all selected scenes finish. `MAX_PARALLEL`, `GPU_ID`, `NUM_WORKERS`, `NUM_EPOCHS`, `ANGULAR_STEP`, and `SCENES` can override the queue defaults.

## Evaluation

`testY.py` computes per-scene and aggregate BT.601 Y-PSNR, Y-SSIM, and RGB LPIPS. Y-SSIM uses the target luminance range, matching the original HyLF `testY.py` protocol. Evaluate all three paper tables from epoch 30 outputs with:

```bash
python testY.py \
  --log-root /path/to/HyLF_runs/logs \
  --dataset all \
  --angular-step 6 \
  --validation-epoch 30 \
  --output-directory /path/to/HyLF_runs/metrics/epoch_30
```

The command writes `hylf_2x2_to_7x7.csv` and `hylf_2x2_to_7x7.json`. The JSON records per-dataset scene coverage and sets `complete` to `true` only when all requested paper scenes are present. To regenerate validation images from existing `last.ckpt` files before evaluating, run:

```bash
DATA_ROOT=/path/to/data \
ARTIFACT_ROOT=/path/to/HyLF_runs \
PYTHON_BIN=/path/to/python \
bash scripts/regenerate_paper_results.sh
```

## Ablations

The repository includes the three paper-oriented alternatives retained by the original experiment code:

```bash
bash scripts/train_ablation_two_plane.sh 0 bicycle 6 HCI_new
bash scripts/train_ablation_multi_plane.sh 0 bicycle 6 HCI_new
bash scripts/train_ablation_planar_voxel.sh 0 bicycle 6 HCI_new
```

- `ablation_two_plane` replaces the learned two-plane ray parameterization with origin-direction rays and removes angular flow.
- `ablation_multi_plane` reduces the plane-intersection feature channels from 32 to 1 and removes angular flow.
- `ablation_planar_voxel` replaces the planar neural voxel decoder with an RGB MLP and removes angular flow.

Hydra overrides can be appended to any script invocation or passed directly to `python train.py`.

## Structure

```text
hylf/                    HyLF system, hybrid ray model, planar sampling and voxel grid
datasets/                sparse angular light-field loading and view splitting
conf/                    HyLF, training, dataset and ablation configurations
scripts/                 training, paper-suite and checkpoint-regeneration entry points
train.py                 PyTorch Lightning training and checkpoint-evaluation entry point
testY.py                 paper-table metric command
evaluate_paper_tables.py metric implementation used by testY.py
```

## Citation

```bibtex
@article{zhao2026hylf,
  title   = {HyLF: Sparse Angular Super-resolution from Hybrid Light Fields without Known Camera Parameters},
  author  = {Zhao, Mingyuan and Yang, Da and Cong, Ruixuan and Cui, Zhenglong and Chen, Rongshan and Ke, Wei and Sheng, Hao},
  journal = {IEEE Transactions on Circuits and Systems for Video Technology},
  year    = {2026},
  doi     = {10.1109/TCSVT.2026.3688726}
}
```

## Acknowledgements

HyLF builds on the [HyperReel](https://github.com/facebookresearch/hyperreel) codebase and its TensoRF-derived planar representation. Consult the upstream projects for their license and attribution information.
